package myRealTrip.partner.function;

public class Count {

}
