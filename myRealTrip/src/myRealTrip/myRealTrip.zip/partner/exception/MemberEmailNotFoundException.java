package myRealTrip.partner.exception;

public class MemberEmailNotFoundException extends RuntimeException {

}
