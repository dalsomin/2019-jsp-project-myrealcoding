package myRealTrip.partner.exception;

public class InvalidPasswordException extends RuntimeException{

}
