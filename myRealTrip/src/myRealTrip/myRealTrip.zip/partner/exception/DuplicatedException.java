package myRealTrip.partner.exception;

import java.io.IOException;

public class DuplicatedException extends IOException{

}
