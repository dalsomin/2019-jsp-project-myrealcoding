package myRealTrip.partner.service;

import myRealTrip.partner.dao.ProfileDAO;

public class ProfileService {

	public void selectprofile(int memberId) {
		ProfileDAO pdao =ProfileDAO.getinstance();
		
		
	}

}
