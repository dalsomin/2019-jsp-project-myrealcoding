package myRealTrip.partner.service;

public class Item_ListService {

}
