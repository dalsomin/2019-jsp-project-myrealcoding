package myRealTrip.partner.dto;

public class B_addinfoDTO {

	private int b_a_code;
	private String b_a_detail;
	
	public int getB_a_code() {
		return b_a_code;
	}
	public void setB_a_code(int b_a_code) {
		this.b_a_code = b_a_code;
	}
	public String getB_a_detail() {
		return b_a_detail;
	}
	public void setB_a_detail(String b_a_detail) {
		this.b_a_detail = b_a_detail;
	}
	
	
	
}
