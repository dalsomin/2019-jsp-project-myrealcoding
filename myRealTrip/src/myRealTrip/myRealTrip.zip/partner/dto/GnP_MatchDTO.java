package myRealTrip.partner.dto;

public class GnP_MatchDTO {

		private int gm_code;
		private String [] gm_type;
		private int memberId;

		
		
		
		public GnP_MatchDTO() {

		}
		public int getGm_code() {
			return gm_code;
		}
		public void setGm_code(int gm_code) {
			this.gm_code = gm_code;
		}
		public String[] getGm_type() {
			return gm_type;
		}
		public void setGm_type(String[] gm_type) {
			this.gm_type = gm_type;
		}
		public int getMemberId() {
			return memberId;
		}
		public void setMemberId(int memberId) {
			this.memberId = memberId;
		}



		
		
		
}
