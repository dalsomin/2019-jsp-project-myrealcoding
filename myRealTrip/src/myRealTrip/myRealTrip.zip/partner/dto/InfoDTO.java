package myRealTrip.partner.dto;

import java.util.Date;

public class InfoDTO {

	private int pn_no;
	private String pn_title;
	private String pn_detail;
	private Date pn_regdate;
	
	public int getPn_no() {
		return pn_no;
	}
	public void setPn_no(int pn_no) {
		this.pn_no = pn_no;
	}
	public String getPn_title() {
		return pn_title;
	}
	public void setPn_title(String pn_title) {
		this.pn_title = pn_title;
	}
	public String getPn_detail() {
		return pn_detail;
	}
	public void setPn_detail(String pn_detail) {
		this.pn_detail = pn_detail;
	}
	public Date getPn_regdate() {
		return pn_regdate;
	}
	public void setPn_regdate(Date pn_regdate) {
		this.pn_regdate = pn_regdate;
	}
	
	
	
	
}
