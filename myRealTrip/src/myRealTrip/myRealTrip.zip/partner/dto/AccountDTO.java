package myRealTrip.partner.dto;

public class AccountDTO {

	
	private int memberId ;
	private String ca_name;
	private String ca_bank;
	private String ca_sno;
	private String ca_swift;
	private String ca_branch ;
	private String ca_addr;
	private String ca_rn;
	
	
	
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public String getCa_name() {
		return ca_name;
	}
	public void setCa_name(String ca_name) {
		this.ca_name = ca_name;
	}
	public String getCa_bank() {
		return ca_bank;
	}
	public void setCa_bank(String ca_bank) {
		this.ca_bank = ca_bank;
	}
	public String getCa_sno() {
		return ca_sno;
	}
	public void setCa_sno(String ca_sno) {
		this.ca_sno = ca_sno;
	}
	public String getCa_swift() {
		return ca_swift;
	}
	public void setCa_swift(String ca_swift) {
		this.ca_swift = ca_swift;
	}
	public String getCa_branch() {
		return ca_branch;
	}
	public void setCa_branch(String ca_branch) {
		this.ca_branch = ca_branch;
	}
	public String getCa_addr() {
		return ca_addr;
	}
	public void setCa_addr(String ca_addr) {
		this.ca_addr = ca_addr;
	}
	public String getCa_rn() {
		return ca_rn;
	}
	public void setCa_rn(String ca_rn) {
		this.ca_rn = ca_rn;
	}
	
	
	
}