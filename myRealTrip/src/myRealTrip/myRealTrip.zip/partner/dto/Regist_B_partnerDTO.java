package myRealTrip.partner.dto;

public class Regist_B_partnerDTO {

	private int memberId;
	private String city;
	private int otherc;
	private String docu_b;    
	private String docu_bacc; 
	private String docu_bcar;
	private int tb_code;
	
	public Regist_B_partnerDTO() {

	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
	
	public int getOtherc() {
		return otherc;
	}

	public void setOtherc(int otherc) {
		this.otherc = otherc;
	}

	public String getDocu_b() {
		return docu_b;
	}

	public void setDocu_b(String docu_b) {
		this.docu_b = docu_b;
	}

	public String getDocu_bacc() {
		return docu_bacc;
	}

	public void setDocu_bacc(String docu_bacc) {
		this.docu_bacc = docu_bacc;
	}

	public String getDocu_bcar() {
		return docu_bcar;
	}

	public void setDocu_bcar(String docu_bcar) {
		this.docu_bcar = docu_bcar;
	}

	public int getTb_code() {
		return tb_code;
	}

	public void setTb_code(int tb_code) {
		this.tb_code = tb_code;
	}
	
	
	
}
