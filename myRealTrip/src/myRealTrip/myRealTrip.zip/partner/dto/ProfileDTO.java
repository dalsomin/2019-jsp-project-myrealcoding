package myRealTrip.partner.dto;

public class ProfileDTO {

}
