package myRealTrip.partner.dto;

public class TaxbillDTO {

	int tb_code;
	String tb_yn;
	String tb_staff;
	String tb_email;
	String tb_why;
	public TaxbillDTO() {
	
	}
	public int getTb_code() {
		return tb_code;
	}
	public void setTb_code(int tb_code) {
		this.tb_code = tb_code;
	}
	public String getTb_yn() {
		return tb_yn;
	}
	public void setTb_yn(String tb_yn) {
		this.tb_yn = tb_yn;
	}
	public String getTb_staff() {
		return tb_staff;
	}
	public void setTb_staff(String tb_staff) {
		this.tb_staff = tb_staff;
	}
	public String getTb_email() {
		return tb_email;
	}
	public void setTb_email(String tb_email) {
		this.tb_email = tb_email;
	}
	public String getTb_why() {
		return tb_why;
	}
	public void setTb_why(String tb_why) {
		this.tb_why = tb_why;
	}
	
	
	
}
