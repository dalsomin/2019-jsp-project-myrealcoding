package myRealTrip.partner.dto;

public class SurveyDTO {
	
		private int memberId ;
		private String know_path; 
		private String mncareer ;
		private String other_ch ;
		private String int_time ;
		private String other_q  ;
		public int getMemberId() {
			return memberId;
		}
		public void setMemberId(int memberId) {
			this.memberId = memberId;
		}
		public String getKnow_path() {
			return know_path;
		}
		public void setKnow_path(String know_path) {
			this.know_path = know_path;
		}
		public String getMncareer() {
			return mncareer;
		}
		public void setMncareer(String mncareer) {
			this.mncareer = mncareer;
		}
		public String getOther_ch() {
			return other_ch;
		}
		public void setOther_ch(String other_ch) {
			this.other_ch = other_ch;
		}
		public String getInt_time() {
			return int_time;
		}
		public void setInt_time(String int_time) {
			this.int_time = int_time;
		}
		public String getOther_q() {
			return other_q;
		}
		public void setOther_q(String other_q) {
			this.other_q = other_q;
		}
		
		
		
}
