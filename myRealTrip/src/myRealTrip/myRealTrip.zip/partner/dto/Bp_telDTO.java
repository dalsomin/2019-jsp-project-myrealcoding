package myRealTrip.partner.dto;

public class Bp_telDTO {
	private int otherc;
	private String [] ocity;
	private String [] otel;
	private String [] olocal_num;
	private String [] oipnum;
	
	
	public Bp_telDTO() {
		
	}
	public int getOtherc() {
		return otherc;
	}
	public void setOtherc(int otherc) {
		this.otherc = otherc;
	}
	public String[] getOcity() {
		return ocity;
	}
	public void setOcity(String[] ocity) {
		this.ocity = ocity;
	}
	public String[] getOtel() {
		return otel;
	}
	public void setOtel(String[] otel) {
		this.otel = otel;
	}
	public String[] getOlocal_num() {
		return olocal_num;
	}
	public void setOlocal_num(String[] olocal_num) {
		this.olocal_num = olocal_num;
	}
	public String[] getOipnum() {
		return oipnum;
	}
	public void setOipnum(String[] oipnum) {
		this.oipnum = oipnum;
	}

	

	
	
}
