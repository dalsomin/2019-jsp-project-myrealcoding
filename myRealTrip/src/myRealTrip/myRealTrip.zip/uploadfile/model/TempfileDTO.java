package myRealTrip.uploadfile.model;

public class TempfileDTO {
	private int SEQ_RP;
	private String FILENAME;
	private String FILEPATH;
	private int MEMBERID;
	private String P_CODE;
	private String TABLENAME;
	public int getSEQ_RP() {
		return SEQ_RP;
	}
	public void setSEQ_RP(int sEQ_RP) {
		SEQ_RP = sEQ_RP;
	}
	public String getFILENAME() {
		return FILENAME;
	}
	public void setFILENAME(String fILENAME) {
		FILENAME = fILENAME;
	}
	public String getFILEPATH() {
		return FILEPATH;
	}
	public void setFILEPATH(String fILEPATH) {
		FILEPATH = fILEPATH;
	}
	public int getMEMBERID() {
		return MEMBERID;
	}
	public void setMEMBERID(int mEMBERID) {
		MEMBERID = mEMBERID;
	}
	public String getP_CODE() {
		return P_CODE;
	}
	public void setP_CODE(String p_CODE) {
		P_CODE = p_CODE;
	}
	public String getTABLENAME() {
		return TABLENAME;
	}
	public void setTABLENAME(String tABLENAME) {
		TABLENAME = tABLENAME;
	}
	
	
	
}
